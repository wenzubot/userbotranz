import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "100"))

DEVS = list(map(int, os.getenv("DEVS", "7734667575").split()))

API_ID = int(os.getenv("API_ID", "22929235"))

API_HASH = os.getenv("API_HASH", "ef9f3dd74cc704f613d38eee2ed5ccdf")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8283064660:AAFMfSyPZMTQAgAcZHupZ-GQsnvAN-c4cEA")

OWNER_ID = int(os.getenv("OWNER_ID", "7734667575"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002784034160").split()))

RMBG_API = os.getenv("RMBG_API", "MA2sUZ4HdAfBegL36HiG4BUG")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://fizzpamell:fizzpamell@cluster0.9nmhi5m.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002784034160"))
