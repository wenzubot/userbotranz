__MODULE__ = "ᴘʀᴇғɪx"
__HELP__ = """
<blockquote><b>Bantuan untuk prefix

perintah : <code>{0}prefix</code> [simbol]
    untuk merubah prefix/handler perintah, tutor none prefix atau tanpa prefix: <a href=https://t.me/@InfoJriiUserbot>ᴄʟɪᴄᴋ ᴜʏʏ</a> </b></blockquote>
"""
