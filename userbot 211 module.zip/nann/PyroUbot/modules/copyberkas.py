__MODULE__ = "ᴄᴏᴘʏ ʙᴇʀᴋᴀs"
__HELP__ = """
<blockquote><b>♛ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴏᴘʏ ʙᴇʀᴋᴀs ♛<b>

<blockquote><b>perintah : 
<code>{0}copy</code> untuk mengambil foto/file/fidio/text yang ada di ch/room private, contoh penggunaan: .copy (link berkas dari room/ch private)</b></blockquote>
"""
